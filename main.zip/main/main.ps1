#region Globals / Paths
$script:AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Add-Type -AssemblyName PresentationFramework

function Load-WindowFromXAML {
    param([Parameter(Mandatory)][string]$XamlPath)

    $xamlContent = Get-Content -Raw -Path $XamlPath
    $reader = New-Object System.Xml.XmlTextReader ([System.IO.StringReader]::new($xamlContent))
    return [System.Windows.Markup.XamlReader]::Load($reader)
}

$authPath            = Join-Path $script:AppRoot "authentication.xaml"
$createUserPath      = Join-Path $script:AppRoot "createUser.xaml"
$groupMembershipPath = Join-Path $script:AppRoot "groupMembership.xaml"
$groupManagementPath = Join-Path $script:AppRoot "groupManagement.xaml"

# Optional config file (keeps upkeep out of code)
$script:ConfigPath = Join-Path $script:AppRoot "customer.config.json"

# Fallback defaults if no config file exists
$script:DefaultGroupsFallback = @(
    "License - M365 Business Premium",
    "MFA Users",
    "SSPR Users",
    "Intune Users",
    "LastPass Users",
    "TEAM"
)
#endregion Globals / Paths

#region Config
function Get-ToolConfig {
    if (Test-Path -LiteralPath $script:ConfigPath) {
        try {
            return (Get-Content -Raw -LiteralPath $script:ConfigPath) | ConvertFrom-Json
        } catch {
            return $null
        }
    }
    return $null
}

function Get-DefaultGroups {
    $cfg = Get-ToolConfig
    if ($cfg -and $cfg.userDefaults -and $cfg.userDefaults.addToGroups -and $cfg.userDefaults.addToGroups.Count -gt 0) {
        return @($cfg.userDefaults.addToGroups)
    }
    return $script:DefaultGroupsFallback
}
#endregion Config

#region Modules + Connection
function Ensure-GraphModules {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
        Install-Module Microsoft.Graph -Scope CurrentUser -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    Import-Module Microsoft.Graph.Users -ErrorAction Stop
    Import-Module Microsoft.Graph.Groups -ErrorAction Stop
}

function Connect-NubrixGraphDelegated {
    $scopes = @(
        "Group.ReadWrite.All",
        "User.ReadWrite.All",
        "Directory.ReadWrite.All"
    )
    Connect-MgGraph -Scopes $scopes -ErrorAction Stop | Out-Null
}
#endregion Modules + Connection

#region Helpers
function Get-RandomPassword {
    param([int]$PasswordLength = 12)

    $lower = (97..122) | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $upper = (65..90)  | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $num   = (48..57)  | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $spec  = ('!','@') | Get-Random -Count 3 | ForEach-Object { $_ }

    $set = $upper + $lower + $num + $spec
    return -join (Get-Random -Count $PasswordLength -InputObject $set)
}

function Show-InfoBox {
    param([string]$Message, [string]$Title = "Info")
    [System.Windows.MessageBox]::Show($Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information) | Out-Null
}

function Show-WarnBox {
    param([string]$Message, [string]$Title = "Warning")
    [System.Windows.MessageBox]::Show($Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Warning) | Out-Null
}

function Show-ErrorBox {
    param([string]$Message, [string]$Title = "Error")
    [System.Windows.MessageBox]::Show($Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error) | Out-Null
}
#endregion Helpers

#region Main Auth Window
$authWindow = Load-WindowFromXAML -XamlPath $authPath

$ConnectToGraphButton   = $authWindow.FindName("ConnectToGraphButton")
$ConnectionTextBlock    = $authWindow.FindName("ConnectionTextBlock")
$CreateUserButton       = $authWindow.FindName("CreateUserButton")
$GroupMembershipButton  = $authWindow.FindName("GroupMembershipButton")
$GroupManagementButton  = $authWindow.FindName("GroupManagementButton")

$CreateUserButton.IsEnabled      = $false
$GroupMembershipButton.IsEnabled = $false
$GroupManagementButton.IsEnabled = $false

$ConnectToGraphButton.Add_Click({
    try {
        Ensure-GraphModules
        Connect-NubrixGraphDelegated

        $ConnectionTextBlock.Text = "Success!"
        $ConnectionTextBlock.Foreground = [System.Windows.Media.Brushes]::Green

        $CreateUserButton.IsEnabled      = $true
        $GroupMembershipButton.IsEnabled = $true
        $GroupManagementButton.IsEnabled = $true
    } catch {
        $ConnectionTextBlock.Text = "Failed to connect."
        $ConnectionTextBlock.Foreground = [System.Windows.Media.Brushes]::Red
        Show-ErrorBox -Message $_.Exception.Message -Title "Connect Failed"
    }
})
#endregion Main Auth Window

#region Create User Window
$CreateUserButton.Add_Click({
    $w = Load-WindowFromXAML -XamlPath $createUserPath

    $FirstNameTextBox          = $w.FindName("FirstNameTextBox")
    $LastNameTextBox           = $w.FindName("LastNameTextBox")
    $EmailTextBox              = $w.FindName("EmailTextBox")
    $AliasTextBox              = $w.FindName("AliasTextBox")
    $TelephoneExtTextBox       = $w.FindName("TelephoneExtTextBox")
    $CountryComboBox           = $w.FindName("CountryComboBox")
    $CreateUserSubmitButton    = $w.FindName("CreateUserSubmitButton")
    $ConfirmCreateUserTextBlock= $w.FindName("ConfirmCreateUserTextBlock")

    $CreateUserSubmitButton.Add_Click({
        $firstName = $FirstNameTextBox.Text.Trim()
        $lastName  = $LastNameTextBox.Text.Trim()
        $email     = $EmailTextBox.Text.Trim()
        $altEmail  = $AliasTextBox.Text.Trim()
        $telExt    = $TelephoneExtTextBox.Text.Trim()

        $countryItem = $CountryComboBox.SelectedItem
        $country = if ($countryItem) { $countryItem.Content.ToString().Trim() } else { $null }

        if ([string]::IsNullOrWhiteSpace($firstName) -or
            [string]::IsNullOrWhiteSpace($lastName) -or
            [string]::IsNullOrWhiteSpace($email) -or
            [string]::IsNullOrWhiteSpace($telExt) -or
            [string]::IsNullOrWhiteSpace($country)) {
            Show-WarnBox -Message "Please fill in all required fields." -Title "Missing Information"
            return
        }

        $password = Get-RandomPassword
        $passwordProfile = @{
            Password = $password
            ForceChangePasswordNextSignIn = $false
        }

        try {
            $params = @{
                DisplayName       = "$firstName $lastName"
                UserPrincipalName = $email
                MailNickname      = ($email.Split('@')[0])
                GivenName         = $firstName
                Surname           = $lastName
                AccountEnabled    = $true
                PasswordProfile   = $passwordProfile
                UsageLocation     = $country
                BusinessPhones    = @($telExt)
            }

            if (-not [string]::IsNullOrWhiteSpace($altEmail)) {
                $params.OtherMails = @($altEmail)
            }

            $newUser = New-MgUser @params -ErrorAction Stop

            $defaultGroups = Get-DefaultGroups

            foreach ($groupName in $defaultGroups) {
                $escaped = $groupName.Replace("'", "''")
                $g = Get-MgGroup -Filter "displayName eq '$escaped'" -ErrorAction SilentlyContinue

                if ($g) {
                    New-MgGroupMemberByRef -GroupId $g.Id -BodyParameter @{
                        "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$($newUser.Id)"
                    } -ErrorAction Stop
                }
            }

            $ConfirmCreateUserTextBlock.Text = "User created successfully."
            Show-InfoBox -Message "User successfully created." -Title "Success"
            $w.Close()

        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Create User Failed"
        }
    })

    $w.ShowDialog() | Out-Null
})
#endregion Create User Window

#region Group Management Window (Add/Remove Membership)
$GroupManagementButton.Add_Click({
    $w = Load-WindowFromXAML -XamlPath $groupManagementPath

    $UserDisplayTextBox              = $w.FindName("UserDisplayTextBox")
    $UserSelectionTextBox            = $w.FindName("UserSelectionTextBox")
    $SelectUserButton                = $w.FindName("SelectUserButton")
    $SelectedUserTextBlock           = $w.FindName("SelectedUserTextBlock")

    $AllGroupsDisplayTextBox         = $w.FindName("AllGroupsDisplayTextBox")
    $GroupSelectionTextBox           = $w.FindName("GroupSelectionTextBox")
    $SelectGroupButton               = $w.FindName("SelectGroupButton")
    $SelectedGroupTextBlock          = $w.FindName("SelectedGroupTextBlock")

    $SelectedInfoDisplayTextBox      = $w.FindName("SelectedInfoDisplayTextBox")
    $ConfirmUserIdSelectionTextBox   = $w.FindName("ConfirmUserIdSelectionTextBox")
    $ConfirmGroupIdSelectionTextBox  = $w.FindName("ConfirmGroupIdSelectionTextBox")
    $ConfirmAddButton                = $w.FindName("ConfirmAddButton")
    $ConfirmRemoveButton             = $w.FindName("ConfirmRemoveButton")

    $script:GM_SelectedUserId = $null
    $script:GM_SelectedGroupId = $null
    $script:GM_AllUsers = @()
    $script:GM_AllGroupsSorted = @()

    function Update-SelectedInfoText {
        $u = if ($script:GM_SelectedUserId) { $script:GM_SelectedUserId } else { "(none)" }
        $g = if ($script:GM_SelectedGroupId) { $script:GM_SelectedGroupId } else { "(none)" }
        $SelectedInfoDisplayTextBox.Text = "User Id:  $u`r`nGroup Id: $g"
        $ConfirmUserIdSelectionTextBox.Text  = if ($script:GM_SelectedUserId) { $script:GM_SelectedUserId } else { "" }
        $ConfirmGroupIdSelectionTextBox.Text = if ($script:GM_SelectedGroupId) { $script:GM_SelectedGroupId } else { "" }
    }

    try {
        $script:GM_AllUsers = Get-MgUser -All -ErrorAction Stop |
            Where-Object { $_.UserPrincipalName -notlike "*onmicrosoft.com" } |
            Sort-Object DisplayName

        $UserDisplayTextBox.Text = ($script:GM_AllUsers | ForEach-Object -Begin { $i = 1 } -Process {
            "[{0}] {1} ({2})" -f $i++, $_.DisplayName, $_.UserPrincipalName
        }) -join "`r`n"
    } catch {
        $UserDisplayTextBox.Text = "Failed to retrieve users: $($_.Exception.Message)"
    }

    try {
        $allGroups = Get-MgGroup -All -ErrorAction Stop
        $script:GM_AllGroupsSorted = $allGroups | ForEach-Object {
            [PSCustomObject]@{
                Id          = $_.Id
                DisplayName = $_.DisplayName
                Type        = if ($_.GroupTypes -contains "Unified") { "M365 Group" } else { "Security Group" }
            }
        } | Sort-Object DisplayName

        $AllGroupsDisplayTextBox.Text = ($script:GM_AllGroupsSorted | ForEach-Object -Begin { $i = 1 } -Process {
            "[{0}] {1} ({2})" -f $i++, $_.DisplayName, $_.Type
        }) -join "`r`n"
    } catch {
        $AllGroupsDisplayTextBox.Text = "Failed to retrieve groups: $($_.Exception.Message)"
    }

    Update-SelectedInfoText

    $SelectUserButton.Add_Click({
        $idx = $UserSelectionTextBox.Text -as [int]
        if (-not $idx -or $idx -le 0 -or $idx -gt $script:GM_AllUsers.Count) {
            $SelectedUserTextBlock.Text = "Invalid selection. Enter 1-$($script:GM_AllUsers.Count)."
            return
        }

        $u = $script:GM_AllUsers[$idx - 1]
        $script:GM_SelectedUserId = $u.Id
        $SelectedUserTextBlock.Text = "Selected User: $($u.DisplayName)"
        Update-SelectedInfoText
    })

    $SelectGroupButton.Add_Click({
        $idx = $GroupSelectionTextBox.Text -as [int]
        if (-not $idx -or $idx -le 0 -or $idx -gt $script:GM_AllGroupsSorted.Count) {
            $SelectedGroupTextBlock.Text = "Invalid selection. Enter 1-$($script:GM_AllGroupsSorted.Count)."
            return
        }

        $g = $script:GM_AllGroupsSorted[$idx - 1]
        $script:GM_SelectedGroupId = $g.Id
        $SelectedGroupTextBlock.Text = "Selected Group: $($g.DisplayName) ($($g.Type))"
        Update-SelectedInfoText
    })

    $ConfirmAddButton.Add_Click({
        $userId  = $ConfirmUserIdSelectionTextBox.Text.Trim()
        $groupId = $ConfirmGroupIdSelectionTextBox.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($userId) -or [string]::IsNullOrWhiteSpace($groupId)) {
            Show-WarnBox -Message "Select a user and group first." -Title "Validation"
            return
        }

        try {
            New-MgGroupMemberByRef -GroupId $groupId -BodyParameter @{
                "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$userId"
            } -ErrorAction Stop

            Show-InfoBox -Message "User added to group successfully." -Title "Success"
        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Add Failed"
        }
    })

    $ConfirmRemoveButton.Add_Click({
        $userId  = $ConfirmUserIdSelectionTextBox.Text.Trim()
        $groupId = $ConfirmGroupIdSelectionTextBox.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($userId) -or [string]::IsNullOrWhiteSpace($groupId)) {
            Show-WarnBox -Message "Select a user and group first." -Title "Validation"
            return
        }

        try {
            Remove-MgGroupMemberDirectoryObjectByRef -GroupId $groupId -DirectoryObjectId $userId -ErrorAction Stop
            Show-InfoBox -Message "User removed from group successfully." -Title "Success"
        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Remove Failed"
        }
    })

    $w.ShowDialog() | Out-Null
})
#endregion Group Management Window

#region Group Membership Window
# You did not paste groupMembership.xaml yet, so I did not refactor this part.
# Once you paste that XAML (and/or the existing handler code), I will update it the same way:
# - cache users once
# - select user once
# - list groups with less API churn
#endregion Group Membership Window

$authWindow.ShowDialog() | Out-Null

Disconnect-MgGraph
