#region Globals / Paths
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# App root resolves to the folder containing Main.ps1 (works when launched via shortcut)
$script:AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# Standard install layout (customer-run)
$script:InstallRoot  = Join-Path $env:ProgramData "Nubrix\AdminTool"
$script:CurrentRoot  = Join-Path $script:InstallRoot "Current"
$script:ConfigRoot   = Join-Path $script:InstallRoot "Config"
$script:LogsRoot     = Join-Path $script:InstallRoot "Logs"

# If running from ProgramData\...\Current, prefer that as the runtime root
if (Test-Path -LiteralPath $script:CurrentRoot) {
    $script:RuntimeRoot = $script:CurrentRoot
} else {
    $script:RuntimeRoot = $script:AppRoot
}

# Create folders (safe even if already present)
foreach ($p in @($script:InstallRoot, $script:CurrentRoot, $script:ConfigRoot, $script:LogsRoot)) {
    if (-not (Test-Path -LiteralPath $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

Add-Type -AssemblyName PresentationFramework

function Load-WindowFromXAML {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$XamlPath)

    if (-not (Test-Path -LiteralPath $XamlPath)) {
        throw "XAML not found: $XamlPath"
    }

    $xamlContent = Get-Content -Raw -LiteralPath $XamlPath
    $reader = New-Object System.Xml.XmlTextReader ([System.IO.StringReader]::new($xamlContent))
    return [System.Windows.Markup.XamlReader]::Load($reader)
}

# XAML paths (expected to live with the app files in RuntimeRoot)
$script:XamlPaths = @{
    Auth            = Join-Path $script:RuntimeRoot "authentication.xaml"
    CreateUser      = Join-Path $script:RuntimeRoot "createUser.xaml"
    GroupMembership = Join-Path $script:RuntimeRoot "groupMembership.xaml"
    GroupManagement = Join-Path $script:RuntimeRoot "groupManagement.xaml"
}

# Config path preference:
# 1) ProgramData\Config (survives app updates)
# 2) RuntimeRoot (legacy / initial installs)
$script:ConfigPathPrimary  = Join-Path $script:ConfigRoot "customer.config.json"
$script:ConfigPathFallback = Join-Path $script:RuntimeRoot "customer.config.json"

# Fallback defaults if no config file exists
$script:DefaultGroupsFallback = @(
    "License - M365 Business Premium",
    "MFA Users",
    "SSPR Users",
    "Intune - Users",
    "Intune - DefaultApps",
    "TEAM"
)

# Basic startup validation (fails fast with clear message)
$missingXaml = @()
foreach ($k in $script:XamlPaths.Keys) {
    if (-not (Test-Path -LiteralPath $script:XamlPaths[$k])) {
        $missingXaml += [string]$script:XamlPaths[$k]
    }
}
if ($missingXaml.Count -gt 0) {
    throw "Missing required XAML file(s):`r`n$($missingXaml -join "`r`n")"
}
#endregion Globals / Paths

#region Config
function Get-ToolConfig {
    [CmdletBinding()]
    param()

    # Prefer ProgramData\Config (survives updates)
    if (Test-Path -LiteralPath $script:ConfigPathPrimary) {
        try {
            return (Get-Content -Raw -LiteralPath $script:ConfigPathPrimary) | ConvertFrom-Json
        } catch {
            throw "Failed to parse config (primary): $script:ConfigPathPrimary`r`n$($_.Exception.Message)"
        }
    }

    # Fallback (legacy): config beside the app files
    if (Test-Path -LiteralPath $script:ConfigPathFallback) {
        try {
            return (Get-Content -Raw -LiteralPath $script:ConfigPathFallback) | ConvertFrom-Json
        } catch {
            throw "Failed to parse config (fallback): $script:ConfigPathFallback`r`n$($_.Exception.Message)"
        }
    }

    throw "Config not found. Expected:`r`n$script:ConfigPathPrimary`r`n(or legacy)`r`n$script:ConfigPathFallback"
}

function Get-DefaultGroups {
    [CmdletBinding()]
    param()

    $cfg = Get-ToolConfig
    if ($cfg -and $cfg.userDefaults -and $cfg.userDefaults.addToGroups -and $cfg.userDefaults.addToGroups.Count -gt 0) {
        return @($cfg.userDefaults.addToGroups)
    }
    return $script:DefaultGroupsFallback
}
#endregion Config

#region Modules + Connection
function Ensure-GraphModules {
    [CmdletBinding()]
    param()

    # Prefer installing for all users if we are elevated (customer-run model), otherwise fall back to CurrentUser
    $isAdmin = $false
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        $isAdmin = $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {}

    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
        $scope = if ($isAdmin) { "AllUsers" } else { "CurrentUser" }
        Install-Module Microsoft.Graph -Scope $scope -Force -AllowClobber
    }

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    Import-Module Microsoft.Graph.Users -ErrorAction Stop
    Import-Module Microsoft.Graph.Groups -ErrorAction Stop
}

function Connect-NubrixGraph {
    [CmdletBinding()]
    param()

    $cfg = Get-ToolConfig
    if (-not $cfg -or -not $cfg.auth) {
        throw "Missing auth configuration. Expected 'auth' section in customer.config.json."
    }

    $mode = ("$($cfg.auth.mode)").Trim().ToLower()
    switch ($mode) {

        "app" {
            $tenantId = ("$($cfg.auth.tenantId)").Trim()
            $clientId = ("$($cfg.auth.clientId)").Trim()
            $thumb    = ("$($cfg.auth.certThumbprint)").Trim()

            if ([string]::IsNullOrWhiteSpace($tenantId) -or
                [string]::IsNullOrWhiteSpace($clientId) -or
                [string]::IsNullOrWhiteSpace($thumb)) {
                throw "Auth mode 'app' requires tenantId, clientId, and certThumbprint in customer.config.json."
            }

            # Cert must exist on the CUSTOMER machine (LocalMachine store)
            $cert = Get-ChildItem -Path Cert:\LocalMachine\My -ErrorAction SilentlyContinue |
                Where-Object { $_.Thumbprint -eq $thumb } |
                Select-Object -First 1

            if (-not $cert) {
                throw "Certificate not found in LocalMachine\My. Thumbprint: $thumb"
            }

            Connect-MgGraph -TenantId $tenantId -ClientId $clientId -CertificateThumbprint $thumb -NoWelcome -ErrorAction Stop | Out-Null
        }

        "delegated" {
            # Break-glass mode (interactive) - keep for troubleshooting
            $scopes = @(
                "Group.ReadWrite.All",
                "User.ReadWrite.All",
                "Directory.ReadWrite.All"
            )
            Connect-MgGraph -Scopes $scopes -ErrorAction Stop | Out-Null
        }

        default {
            throw "Unsupported auth mode '$mode'. Use 'app' or 'delegated'."
        }
    }
}
#endregion Modules + Connection

#region Helpers
function Get-RandomPassword {
    [CmdletBinding()]
    param([int]$PasswordLength = 12)

    if ($PasswordLength -lt 12) { $PasswordLength = 12 }

    $lower = (97..122) | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $upper = (65..90)  | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $num   = (48..57)  | Get-Random -Count 3 | ForEach-Object { [char]$_ }
    $spec  = ('!','@') | Get-Random -Count 3 | ForEach-Object { $_ }

    $set = $upper + $lower + $num + $spec
    return -join (Get-Random -Count $PasswordLength -InputObject $set)
}

function Show-InfoBox {
    [CmdletBinding()]
    param([string]$Message, [string]$Title = "Info")

    [System.Windows.MessageBox]::Show(
        $Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null
}

function Show-WarnBox {
    [CmdletBinding()]
    param([string]$Message, [string]$Title = "Warning")

    [System.Windows.MessageBox]::Show(
        $Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Warning
    ) | Out-Null
}

function Show-ErrorBox {
    [CmdletBinding()]
    param([string]$Message, [string]$Title = "Error")

    [System.Windows.MessageBox]::Show(
        $Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
}
#endregion Helpers

#region Main Auth Window
$authWindow = Load-WindowFromXAML -XamlPath $script:XamlPaths.Auth

$ConnectToGraphButton   = $authWindow.FindName("ConnectToGraphButton")
$ConnectionTextBlock    = $authWindow.FindName("ConnectionTextBlock")
$CreateUserButton       = $authWindow.FindName("CreateUserButton")
$GroupMembershipButton  = $authWindow.FindName("GroupMembershipButton")
$GroupManagementButton  = $authWindow.FindName("GroupManagementButton")

$CreateUserButton.IsEnabled      = $false
$GroupMembershipButton.IsEnabled = $false
$GroupManagementButton.IsEnabled = $false

$ConnectToGraphButton.Add_Click({
    try {
        Ensure-GraphModules
        Connect-NubrixGraph

        $ConnectionTextBlock.Text = "Connected"
        $ConnectionTextBlock.Foreground = [System.Windows.Media.Brushes]::Green

        $CreateUserButton.IsEnabled      = $true
        $GroupMembershipButton.IsEnabled = $true
        $GroupManagementButton.IsEnabled = $true
    } catch {
        $ConnectionTextBlock.Text = "Connection failed"
        $ConnectionTextBlock.Foreground = [System.Windows.Media.Brushes]::Red
        Show-ErrorBox -Message $_.Exception.Message -Title "Connect Failed"
    }
})
#endregion Main Auth Window

#region Create User Window
$CreateUserButton.Add_Click({
    $w = Load-WindowFromXAML -XamlPath $script:XamlPaths.CreateUser

    $FirstNameTextBox           = $w.FindName("FirstNameTextBox")
    $LastNameTextBox            = $w.FindName("LastNameTextBox")
    $EmailTextBox               = $w.FindName("EmailTextBox")
    $AliasTextBox               = $w.FindName("AliasTextBox")
    $TelephoneExtTextBox        = $w.FindName("TelephoneExtTextBox")
    $CountryComboBox            = $w.FindName("CountryComboBox")
    $CreateUserSubmitButton     = $w.FindName("CreateUserSubmitButton")
    $ConfirmCreateUserTextBlock = $w.FindName("ConfirmCreateUserTextBlock")

    $CreateUserSubmitButton.Add_Click({
        $firstName = $FirstNameTextBox.Text.Trim()
        $lastName  = $LastNameTextBox.Text.Trim()
        $email     = $EmailTextBox.Text.Trim()
        $altEmail  = $AliasTextBox.Text.Trim()
        $telExt    = $TelephoneExtTextBox.Text.Trim()

        $countryItem = $CountryComboBox.SelectedItem
        $country = if ($countryItem) { $countryItem.Content.ToString().Trim() } else { $null }

        if ([string]::IsNullOrWhiteSpace($firstName) -or
            [string]::IsNullOrWhiteSpace($lastName) -or
            [string]::IsNullOrWhiteSpace($email) -or
            [string]::IsNullOrWhiteSpace($telExt) -or
            [string]::IsNullOrWhiteSpace($country)) {
            Show-WarnBox -Message "Please fill in all required fields." -Title "Missing Information"
            return
        }

        $password = Get-RandomPassword
        $passwordProfile = @{
            Password = $password
            ForceChangePasswordNextSignIn = $false
        }

        try {
            $params = @{
                DisplayName       = "$firstName $lastName"
                UserPrincipalName = $email
                MailNickname      = ($email.Split('@')[0])
                GivenName         = $firstName
                Surname           = $lastName
                AccountEnabled    = $true
                PasswordProfile   = $passwordProfile
                UsageLocation     = $country
                BusinessPhones    = @($telExt)
            }

            if (-not [string]::IsNullOrWhiteSpace($altEmail)) {
                $params.OtherMails = @($altEmail)
            }

            $newUser = New-MgUser @params -ErrorAction Stop

            $defaultGroups = Get-DefaultGroups
            foreach ($groupName in $defaultGroups) {
                $escaped = $groupName.Replace("'", "''")
                $g = Get-MgGroup -Filter "displayName eq '$escaped'" -ErrorAction SilentlyContinue

                if ($g) {
                    New-MgGroupMemberByRef -GroupId $g.Id -BodyParameter @{
                        "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$($newUser.Id)"
                    } -ErrorAction Stop
                }
            }

            $ConfirmCreateUserTextBlock.Text = "User created successfully."
            Show-InfoBox -Message "User successfully created." -Title "Success"
            $w.Close()

        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Create User Failed"
        }
    })

    $w.ShowDialog() | Out-Null
})
#endregion Create User Window

#region Group Management Window (Add/Remove Membership)
$GroupManagementButton.Add_Click({
    $w = Load-WindowFromXAML -XamlPath $script:XamlPaths.GroupManagement

    $UserDisplayTextBox              = $w.FindName("UserDisplayTextBox")
    $UserSelectionTextBox            = $w.FindName("UserSelectionTextBox")
    $SelectUserButton                = $w.FindName("SelectUserButton")
    $SelectedUserTextBlock           = $w.FindName("SelectedUserTextBlock")

    $AllGroupsDisplayTextBox         = $w.FindName("AllGroupsDisplayTextBox")
    $GroupSelectionTextBox           = $w.FindName("GroupSelectionTextBox")
    $SelectGroupButton               = $w.FindName("SelectGroupButton")
    $SelectedGroupTextBlock          = $w.FindName("SelectedGroupTextBlock")

    $SelectedInfoDisplayTextBox      = $w.FindName("SelectedInfoDisplayTextBox")
    $ConfirmUserIdSelectionTextBox   = $w.FindName("ConfirmUserIdSelectionTextBox")
    $ConfirmGroupIdSelectionTextBox  = $w.FindName("ConfirmGroupIdSelectionTextBox")
    $ConfirmAddButton                = $w.FindName("ConfirmAddButton")
    $ConfirmRemoveButton             = $w.FindName("ConfirmRemoveButton")

    $script:GM_SelectedUserId = $null
    $script:GM_SelectedGroupId = $null
    $script:GM_AllUsers = @()
    $script:GM_AllGroupsSorted = @()

    function Update-SelectedInfoText {
        $u = if ($script:GM_SelectedUserId) { $script:GM_SelectedUserId } else { "(none)" }
        $g = if ($script:GM_SelectedGroupId) { $script:GM_SelectedGroupId } else { "(none)" }
        $SelectedInfoDisplayTextBox.Text = "User Id:  $u`r`nGroup Id: $g"
        $ConfirmUserIdSelectionTextBox.Text  = if ($script:GM_SelectedUserId) { $script:GM_SelectedUserId } else { "" }
        $ConfirmGroupIdSelectionTextBox.Text = if ($script:GM_SelectedGroupId) { $script:GM_SelectedGroupId } else { "" }
    }

    try {
        $script:GM_AllUsers = Get-MgUser -All -ErrorAction Stop |
            Where-Object { $_.UserPrincipalName -notlike "*onmicrosoft.com" } |
            Sort-Object DisplayName

        $UserDisplayTextBox.Text = ($script:GM_AllUsers | ForEach-Object -Begin { $i = 1 } -Process {
            "[{0}] {1} ({2})" -f $i++, $_.DisplayName, $_.UserPrincipalName
        }) -join "`r`n"
    } catch {
        $UserDisplayTextBox.Text = "Failed to retrieve users: $($_.Exception.Message)"
    }

    try {
        $allGroups = Get-MgGroup -All -ErrorAction Stop
        $script:GM_AllGroupsSorted = $allGroups | ForEach-Object {
            [PSCustomObject]@{
                Id          = $_.Id
                DisplayName = $_.DisplayName
                Type        = if ($_.GroupTypes -contains "Unified") { "M365 Group" } else { "Security Group" }
            }
        } | Sort-Object DisplayName

        $AllGroupsDisplayTextBox.Text = ($script:GM_AllGroupsSorted | ForEach-Object -Begin { $i = 1 } -Process {
            "[{0}] {1} ({2})" -f $i++, $_.DisplayName, $_.Type
        }) -join "`r`n"
    } catch {
        $AllGroupsDisplayTextBox.Text = "Failed to retrieve groups: $($_.Exception.Message)"
    }

    Update-SelectedInfoText

    $SelectUserButton.Add_Click({
        $idx = $UserSelectionTextBox.Text -as [int]
        if (-not $idx -or $idx -le 0 -or $idx -gt $script:GM_AllUsers.Count) {
            $SelectedUserTextBlock.Text = "Invalid selection. Enter 1-$($script:GM_AllUsers.Count)."
            return
        }

        $u = $script:GM_AllUsers[$idx - 1]
        $script:GM_SelectedUserId = $u.Id
        $SelectedUserTextBlock.Text = "Selected User: $($u.DisplayName)"
        Update-SelectedInfoText
    })

    $SelectGroupButton.Add_Click({
        $idx = $GroupSelectionTextBox.Text -as [int]
        if (-not $idx -or $idx -le 0 -or $idx -gt $script:GM_AllGroupsSorted.Count) {
            $SelectedGroupTextBlock.Text = "Invalid selection. Enter 1-$($script:GM_AllGroupsSorted.Count)."
            return
        }

        $g = $script:GM_AllGroupsSorted[$idx - 1]
        $script:GM_SelectedGroupId = $g.Id
        $SelectedGroupTextBlock.Text = "Selected Group: $($g.DisplayName) ($($g.Type))"
        Update-SelectedInfoText
    })

    $ConfirmAddButton.Add_Click({
        $userId  = $ConfirmUserIdSelectionTextBox.Text.Trim()
        $groupId = $ConfirmGroupIdSelectionTextBox.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($userId) -or [string]::IsNullOrWhiteSpace($groupId)) {
            Show-WarnBox -Message "Select a user and group first." -Title "Validation"
            return
        }

        try {
            New-MgGroupMemberByRef -GroupId $groupId -BodyParameter @{
                "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$userId"
            } -ErrorAction Stop

            Show-InfoBox -Message "User added to group successfully." -Title "Success"
        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Add Failed"
        }
    })

    $ConfirmRemoveButton.Add_Click({
        $userId  = $ConfirmUserIdSelectionTextBox.Text.Trim()
        $groupId = $ConfirmGroupIdSelectionTextBox.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($userId) -or [string]::IsNullOrWhiteSpace($groupId)) {
            Show-WarnBox -Message "Select a user and group first." -Title "Validation"
            return
        }

        try {
            Remove-MgGroupMemberDirectoryObjectByRef -GroupId $groupId -DirectoryObjectId $userId -ErrorAction Stop
            Show-InfoBox -Message "User removed from: $groupId" -Title "Success"
        } catch {
            Show-ErrorBox -Message $_.Exception.Message -Title "Remove Failed"
        }
    })

    $w.ShowDialog() | Out-Null
})
#endregion Group Management Window

#region Group Membership Window
$GroupMembershipButton.Add_Click({
    $w = Load-WindowFromXAML -XamlPath $script:XamlPaths.GroupMembership

    $UserDisplayTextBox    = $w.FindName("UserDisplayTextBox")
    $UserSelectionTextBox  = $w.FindName("UserSelectionTextBox")
    $SelectUserButton      = $w.FindName("SelectUserButton")
    $SelectedUserTextBlock = $w.FindName("SelectedUserTextBlock")
    $GroupsDisplayTextBox  = $w.FindName("GroupsDisplayTextBox")
    $CloseButton           = $w.FindName("CloseGroupMembershipWindowButton")

    $script:GMEM_AllUsers = @()

    $CloseButton.Add_Click({ $w.Close() })

    try {
        $script:GMEM_AllUsers = Get-MgUser -All -ErrorAction Stop |
            Where-Object { $_.UserPrincipalName -notlike "*onmicrosoft.com" } |
            Sort-Object DisplayName

        if (-not $script:GMEM_AllUsers -or $script:GMEM_AllUsers.Count -eq 0) {
            $UserDisplayTextBox.Text = "No users matched the filter."
        } else {
            $UserDisplayTextBox.Text = ($script:GMEM_AllUsers | ForEach-Object -Begin { $i = 1 } -Process {
                "[{0}] {1} ({2})" -f $i++, $_.DisplayName, $_.UserPrincipalName
            }) -join "`r`n"
        }
    } catch {
        $UserDisplayTextBox.Text = "Failed to retrieve users: $($_.Exception.Message)"
    }

    $SelectUserButton.Add_Click({
        $idx = $UserSelectionTextBox.Text -as [int]
        if (-not $idx -or $idx -le 0 -or $idx -gt $script:GMEM_AllUsers.Count) {
            $SelectedUserTextBlock.Text = "Invalid selection. Enter 1-$($script:GMEM_AllUsers.Count)."
            return
        }

        $u = $script:GMEM_AllUsers[$idx - 1]
        $SelectedUserTextBlock.Text = "Selected User: $($u.DisplayName)"

        try {
            $memberOf = Get-MgUserMemberOf -UserId $u.Id -All -ErrorAction Stop

            if (-not $memberOf -or $memberOf.Count -eq 0) {
                $GroupsDisplayTextBox.Text = "The selected user is not a member of any groups."
                return
            }

            $names = foreach ($obj in $memberOf) {
                # Some directoryObjects won't be Groups; attempt to resolve to group displayName
                try {
                    $g = Get-MgGroup -GroupId $obj.Id -ErrorAction Stop
                    $t = if ($g.GroupTypes -contains "Unified") { "M365 Group" } else { "Security Group" }
                    "$($g.DisplayName) ($t)"
                } catch {
                    $null
                }
            }

            $names = $names | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Sort-Object
            if (-not $names -or $names.Count -eq 0) {
                $GroupsDisplayTextBox.Text = "No group memberships could be resolved."
            } else {
                $GroupsDisplayTextBox.Text = ($names -join "`r`n")
            }
        } catch {
            $GroupsDisplayTextBox.Text = "Failed to retrieve group memberships: $($_.Exception.Message)"
        }
    })

    $w.ShowDialog() | Out-Null
})
#endregion Group Membership Window

$authWindow.ShowDialog() | Out-Null

Disconnect-MgGraph
